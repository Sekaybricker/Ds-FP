private void habilitaCamposItem(bool hab) 
cmbProduto.EnabIed = hab; 
nudQuantidade.EnabIed = hab; 
private void habilitaaotoes (bool hab) 
btnlncluir. Enabled 
= hab; 
btnExcIuir.EnabIed = 
hab; 
btnAIterar. Enabled 
= hab; 
btnPesquisar.EnabIed = hab; 
btnSair.EnabIed = hab; 
btnGravar.EnabIed = !hab; 
btnCanceIar.EnabIed = !hab; 
private void habilitaaotoesltem(bool hab) 
btnlncluirltem. Enabled 
= hab; 
btnExcIuirItem. Enabled = 
hab; 
btnAItera rltem. Ena bled 
= hab; 
btnPesquisarItem.EnabIed = hab; 
btnSair.EnabIed = hab; 
btnGravarItem. Enabled = !hab; 
btnCanceIarItem. Enabled = !hab; 
private void limpaCampos (Control 
local)// (Form form) //TODO mostrar 
foreach (Control 
item in local. Controls)/ 'form. Controls) 
if (item is is Text30x item is masked Textaox) 
( (Textaox) item) . Clear ; 
if ( ( (Textaox)item) . Name 
"txtPrecoLlnit" 
( (Text80x) item) . Name 
( (Textaox) item) . Name 
if (item is 
NumericlJpDown) 
( (NumericlJpDown)item) . Value = 
if (item is 
masked Textaox) 
"txtSubTotaI" 
"txtTotaI" ) 
( (ma s ked Textaox) item) . Clear ; 
if (item is 
Combo Box) 
if ( ( (Comboaox)item) . Items . Count > e) 
( (Conboaox)item) . Selectedlndex = e; 
if (item is DateTimePicker) 
( (DateTimePicker)item) . Value = 
DateTime. Now; 
private void sender, 
incluir = true; 
habilitaCampos (true) ; 
habilita80toes (false); 
txtNumVenda . Focus ( ) 
EventArgs e) 
