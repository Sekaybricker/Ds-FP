private void btnAIterarItem Click(object sender, 
if (dgvltens .SeIectedRows . Count > e) 
editarltem = true; 
ha Item (false) ; 
ha Item (true) ; 
cmbProduto.Text = 
EventArgs e) 
dgvItensCI, dgvltens .CurrentRow. Index) . Value. Tostring(); 
// evitar de valor igual no cmbProduto 
cmbProduto_SeIectedIndexChanged (null, null); 
nudQuantidade.VaIue = 
. Tolnt32( 
Convert 
dgvItensC2, dgvltens .CurrentRow. Index) . Value. Tostring()); 

cmbProduto. Focus ( ) ; 
else 
messageaox.Show(nuII, "Selecione uma ITEM primeiro! " , 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
- 
- 
private void btnpesquisarltem Click(object sender, 
try 
if (dgvltens. RowCount > e) 
// alterar ' cmbCIiente' ou ' cmbCodCIi ' 
if (cmbProduto.EnabIed false) 
cmbProduto. Enabled = true; 
cmbProduto. Focus ( ) ; 
ha Item (false) ; 
btnpesquisarltem. Enabled = true; 
btnGravarItem. Enabled = false; 
btnCanceIarItem. Enabled = false; 
EventArgs e) 
p/ cmbProduto ou cmbCodPro 
message80x.Show(nuII, "Digite o nome do ITEM desejado ou" 
else 
pc 
"\nparte dele. "Pesquisa" 
message80x8uttons . OK, 
messageaoxlcon . Information ) ; 
itemvendaTa bleAda pter. F illayDes c ricao (th is . Venda sDataSet. pc_itemvenda , 
. Tolnt32( 
Convert 
dgvVendasCø, dgvVendas .CurrentRow. Index) . Value. Tostring()), 
+ cmbProduto.Text + 
null); 
else 
messageaox.Show(nuII, 
"Cadastre um item primeiro! " 
"Erro ao excluir:", 
messageaoxlcon . Error) ; 
message80x8uttons . OK, 
catch (Exception 
ex) 
messageaox.Show(nuII, "Ocorreu um erro: 
ex. mes sage, 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
private void btnCanceIarItem Click(object sender, 
limpaCampos (grpltem) ; 
habilitaCampos Item (false) ; 
h a Item (true) ; 
editarltem = false; 
incluirltem = false; 
EventArgs e) 
