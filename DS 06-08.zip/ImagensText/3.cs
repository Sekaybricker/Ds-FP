
private void cmbProduto SelectedIndexChanged (object sender, EventArgs e) 
DataTabIe produto = 
// Zerar precoTemp para garantir o calculo 
precoTemp = a; 
foreach (DataRow rcnh' in produto.Rows) // Loop "nas Iinhas". 
Convert. ToDoubIe(rowC " precounit"] . ToString()) ; 
precoTemp 
nudQuantidade.VaIue = I; 
txtPrecoLlnit.Text = 
txtSubTotaI.Text = 
private void nudQuantidade_VaIueChanged (object sender, EventArgs e) 
double subTotaI = 
txtS u bTota I. Text 
(Int32)nudQuantidade.VaIue * precoTemp; 
private void btnExcIuirItem Click(object sender, EventArgs e) 
try 
if 
Tncar nome do DataGridView para 'dgvVendas ' 
(dgvltens .SeIectedRows . Count > e) 
if (message30x.Show(nuII, "Deseja mesmo excluir o ITEM selecionado?" 
"Atencäo: " 
message80x8uttons . YesNo, Messageaoxlcon . Question, 
message80xDefauIt8utton . Button 2) 
System. Windows . Forms . DialogResuIt. Yes) 
pc _itemvend a T a bleAd a pter. Delete ( 
//trocar a mensagem 
. Tolnt32(dgvVendasCø, dgvVendas Index) . Value. Tostring()), 
Convert 
Convert. Tolnt32(dgvItensCø, dgvltens .CurrentRow. Index) . Value. Tostring()) 
null); 
message80x.Show(nuII, "Apagado com sucesso!", 
"Exclusäo", 
message80xIcon . Information ) ; 
message80x8uttons . OK, 
else 
messageaox.Show(nuII, 
"Selecione uma item primeiro! " 
"Erro ao excluir:", 
messageaoxlcon . Error) ; 
message80x8uttons . OK, 
catch (Exception 
ex) 
messageaox.Show(nuII, "Ocorreu um erro: 
ex. mes sage, 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
