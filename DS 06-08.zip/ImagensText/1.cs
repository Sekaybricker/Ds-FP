using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
le  namespace prjVendas 

public partial class 
FrmVendas 
bool incluir = false; 
bool editar = false; 
bool editarltem = false; 
bool incluirltem = false; 
double precoTemp = e; 
public FrrnVendas() 
In itia lizeComponent() ; 
. Form 
private void FrmVendas Load (object sender, EventArgs e) 
// TODO: This line of code loads data into the 'vendasDataSet.pc_itemvenda' table. You can move, or remove it, as needed. 
/ 'this . pc_itemvendaTabIeAdapter. F ill (this . vendasDataSet. pc_itemvenda ) ; 
// TODO: This line of code loads data into the 'vendasDataSet.pc_venda' table. You can move, or remove it, as needed. 
this . pc_vendaTabIeAdapter. F ill (this . vendasDataSet. pc_venda ) ; 
// TODO: This line of code loads data into the 'vendasDataSet.pc_produto' table. You can move, or remove it, as needed. 
this . pc_produtoTabIeAdapter. F ill (this . vendasDataSet . pc_produto) ; 
// TODO: This line of code loads data into the 'vendasDataSet.pc_cIientes' table. You can move, or remove it, as needed. 
this . pc_cIientesTabIeAdapter. F ill (this . vendasDataSet. pc_clientes ) ; 
if (dgvVendas.Rows.Count > e) 
dgvVendas . Rows . Selected 
— true; 
/ 'Programe PRIMEIRO os métodos: habilitaCampos , habilitaCamposItem, 
// e limpaCampos; Pois säo pré-requisitos dos botöes 
private void habilitaCampos (bool hab) 
txtNumVenda.EnabIed = hab; 
cmbCIiente.EnabIed = hab; 
dtpDataVenda.EnabIed = hab; 
dtpDataEntrega.EnabIed = hab; 
txtObs.EnabIed = hab; 
h a Item 