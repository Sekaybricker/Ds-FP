private void dgvVendas SelectionChanged (object sender, 
try 
if (dgvVendas. RowCount > e) //TODO mostrar 
EventArgs e) 
this . pc_itemvendaTabIeAdapter. F illayNumVenda (this . vendasDataSet. pc_itemvenda , 
. Tolnt32(dgvVendasCø, dgvVendas.CurrentRow. Index) . Value. Tostring())); 
Convert 
if (dgvItens.RowCount > e) 
double total = 
. Tolnt32(dgvVendasCø, dgvVendas Index) . Value. Tostring())); 
Convert 
txtTota I. Text 
else 
txtTota I. Text = 
catch (Exception 
ex) 
messageaox.Show(nuII, 
"R$ a,øø"; 
"Ocorreu um erro: 
ex. message, 
"Erro ao acessar os Items da VENDA: " 
messageaoxauttons . OK, 
messageaoxlcon . Error) ; 
private void sender, 
try 
if 
Tncar nome do DataGridView para 
EventArgs e) 
'dgvVendas ' 
(dgvVendas.SeIectedRows . Count > e) 
if (message30x.Show(nuII, "Deseja mesmo excluir a VENDA selecionada?", 
"Atencäo: " 
message80x8uttons . YesNo, messageaoxlcon . Question, 
message80xDefauIt8utton . Button2) 
System. Windows . Forms . DialogResuIt. Yes) 
pc _itemvend a T a bleAd a pter. DeleteTodos (Convert. Tol nt32 ( 
dgvVendasCø, dgvVendas Index) . Value. Tostring())); 
pc _vend a T a bleAd a pter. Delete (Convert . 
Tolnt32( 
dgvVendasCø, dgvVendas Index) . Value. Tostring())); 
null); 
messageaox.Show(nuII, "Apagado com sucesso!", 
"Exclusäo", 
message80xIcon . Information ) ; 
message80x8uttons . OK, 
//trocar a mensagem 
else 
messageaox.Show(nuII, 
"Selecione uma Venda primeiro! " 
"Erro ao excluir:", 
messageaoxlcon . Error) ; 
message80x8uttons . OK, 
catch (Exception 
ex) 
messageaox.Show(nuII, "Ocorreu um erro: 
ex. mes sage, 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
private void sender, 
EventArgs e) 
try 
if 
if 
(incluir) 
pc_vendaTabIeAdapter. Insert (Convert . Tolnt32 (txtNumVenda . Text) , 
(Int32)cmbCIiente.SeIectedVaIue, dtpDataVenda . Value, 
dtpDataEntrega . Value, txtObs . Text); 
messageaox.Show(nuII, 
'Incluido com sucesso!", 
'Inclusäo", 
message80xIcon . Information ) ; 
message80x8uttons . OK, 
dtpDataVenda.VaIue, 
dtpDataEntrega . Value, txtObs . Text, 
. Tolnt32 (txtNumVenda . Text) ) ; 
Convert 
messageaox.Show(nuII, "Alterado com sucesso!", 
"Alteracäo" , 
message80xIcon . Information ) ; 
message80x8uttons . OK, 
null); 
FrmVendas Load (null, null); 
catch (Exception 
ex) 
messageaox.Show(nuII, "Ocorreu um erro: ' 
ex. message, 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
