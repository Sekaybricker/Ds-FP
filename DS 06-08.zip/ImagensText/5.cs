private void btnCanceIar Click(object sender, 
EventArgs e) 
limpaCampos (this); //TODO mostrar 
limpaCampos (grpltem) ; 
habilitaCampos (false); 
habilita80toes (true) ; 
editar = false; 
incluir = false; 
private void sender, 
Close() ; 
EventArgs e) 
private void sender, 
if (dgvVendas . SelectedRows . Count > e) 
editar = true; 
habilita80toes (false) ; 
habilitaCampos (true) ; 
txtNumVenda.EnabIed = false; 
txtNumVenda . Text = 
EventArgs e) 
dgvVendasCø, dgvVendas .CurrentRow. Index) . Value. Tostring(); 
cmbCIiente.SeIectedVaIue = 
. Tolnt32( 
Convert 
dgvVendasCI, dgvVendas Index) . Value. Tostring()); 
dtpDataVenda . Value = 
Convert . ToDateTime ( 
dgvVendasC3, dgvVendas Index) . Value. Tostring()); 
dtpDataEntrega . Value = 
Convert . ToDateTime ( 
dgvVendasC4, dgvVendas Index) . Value. Tostring()); 
txtObs.Text = dgvVendasC5, dgvVendas.CurrentRow.Index) . Value. Tostring(); 
cmbCIiente. Focus ( ) ; 
else 
messageaox.Show(nuII, "Selecione uma VENDA primeiro! " , 
message80xIcon . Error) ; 
message80x8uttons . OK, 
"Erro: " 
private void sender, 
if (cmbCIiente. Enabled false) 
cmbCIiente. Enabled = true; 
cmbCIiente. Focus ( ) ; 
habilita80toes (false) ; 
btnPesquisar.EnabIed = true; 
btnGravar.EnabIed = false; 
btnCanceIar.EnabIed = false; 
EventArgs e) 
message80x.Show(nuII, "Digite o nome do cliente desejado ou" 
"\nparte dele." , 
'Pesquisa" 
message80x8uttons . OK, 
messageaoxlcon . Information ) ; 
else 
pc_vendaTabIeAdapter. F illayNome (this . vendasDataSet. pc_venda , 
+ cmbCIiente.Text + 
null); 
private void btnlncluirltem Click(object sender, 
EventArgs e) 
incluirltem = true; 
ha Item (true) ; 
habilita80toesItem(faIse) ; 
cmbProd uto_SeIected I ndexCh a need ( n u 11, 
cmbProduto. Focus ( ) ; 
null); 
