﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmCadCliente : Form
    {
        bool incluir = false;
        bool alterar = false;
        Util util = new Util();
        public FrmCadCliente()
        {
            InitializeComponent();
        }

        private void pc_clientesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pc_clientesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet1);

        }

        private void FrmCadCliente_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.pc_clientes' table. You can move, or remove it, as needed.
            this.pc_clientesTableAdapter.Fill(this.dataSet1.pc_clientes);

        }

        private void ufLabel_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void pc_clientesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            util.HabilitaBotoes(false, Controls);
            util.HabilitaCampos(false, Controls);
            incluir = true;
            txtCod_cli.Enabled = false;
            txtNome.Focus();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {

        }

        private void btnGravar_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }
    }
}
