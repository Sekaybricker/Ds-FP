﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    class Util
    {
        public void  HabilitaBotoes(bool hab, Control.ControlCollection control)
        {
            foreach (Control item in control)
            {
                if (item is Button)
                {
                    item.Enabled = hab;
                    if (item.Name == "btnGravar" || item.Name =="btnCancelar")
                    {
                        item.Enabled = !hab;
                    }
                }
            }
        }
        public void HabilitaCampos(bool hab, Control.ControlCollection control)
        {
            foreach (Control item in control)
            {
                if (!(item is Label) ||!(item is Button) || !(item is DataGridView))
                {
                    item.Enabled = hab;
                }
            }   
        }
        public void LimparCampos(Control.ControlCollection control)
        {
            foreach (Control item in control)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).Clear();
                }
                if (item is MaskedTextBox)
                {
                    ((MaskedTextBox)item).Clear();
                }
                if (item is DateTimePicker)
                {
                   ((DateTimePicker)item).Value = DateTime.Now;
                }
            }
        }
    }
}
