﻿namespace WindowsFormsApplication1
{


    partial class DataSet1
    {
        partial class pc_produtosDataTable
        {
        }
    }
}
